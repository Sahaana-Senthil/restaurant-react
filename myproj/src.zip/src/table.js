import React, { useState } from "react";
import "./table.css";

function TableReservationPage() {
    const [formData, setFormData] = useState({
        username: "",
        email: "",
        phone: "",
        date: "",
        purpose: "",
        persons: "",
    });

    const [errors, setErrors] = useState({});

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    const validateForm = () => {
        let formErrors = {};
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const phonePattern = /^[0-9]{10}$/;

        if (!formData.username) formErrors.username = "Username is required";
        if (!formData.email || !emailPattern.test(formData.email))
            formErrors.email = "Invalid email";
        if (!formData.phone || !phonePattern.test(formData.phone))
            formErrors.phone = "Invalid phone number";
        if (!formData.date) formErrors.date = "Date is required";
        if (!formData.purpose) formErrors.purpose = "Purpose is required";
        if (!formData.persons) formErrors.persons = "Please enter the number of persons";

        return formErrors;
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const formErrors = validateForm();
        if (Object.keys(formErrors).length === 0) {
            alert("Table Reserved Successfully!");
        } else {
            setErrors(formErrors);
        }
    };

    return (
        <div className="reservation-page">
            <h1>Table Reservation</h1>
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Username:</label>
                    <input
                        type="text"
                        name="username"
                        value={formData.username}
                        onChange={handleChange}
                        placeholder="Enter your username"
                    />
                    {errors.username && <p className="error">{errors.username}</p>}
                </div>
                <div className="form-group">
                    <label>Email:</label>
                    <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="Enter your email"
                    />
                    {errors.email && <p className="error">{errors.email}</p>}
                </div>
                <div className="form-group">
                    <label>Phone Number:</label>
                    <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        placeholder="Enter your phone number"
                    />
                    {errors.phone && <p className="error">{errors.phone}</p>}
                </div>
                <div className="form-group">
                    <label>Date:</label>
                    <input
                        type="date"
                        name="date"
                        value={formData.date}
                        onChange={handleChange}
                    />
                    {errors.date && <p className="error">{errors.date}</p>}
                </div>
                <div className="form-group">
                    <label>Purpose:</label>
                    <input
                        type="text"
                        name="purpose"
                        value={formData.purpose}
                        onChange={handleChange}
                        placeholder="Enter the purpose"
                    />
                    {errors.purpose && <p className="error">{errors.purpose}</p>}
                </div>
                <div className="form-group">
                    <label>Approximate Number of Persons:</label>
                    <input
                        type="number"
                        name="persons"
                        value={formData.persons}
                        onChange={handleChange}
                        placeholder="Enter the number of persons"
                    />
                    {errors.persons && <p className="error">{errors.persons}</p>}
                </div>
                <button type="submit" className="book-table-btn">
                    Book Table
                </button>
            </form>
        </div>
    );
}

export default TableReservationPage;
