import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <nav>
        <ul>
          <li><a href="#pm">PING ME</a><br></br></li>
          <li><a href="#aboutus">ABOUT US</a><br></br></li>
          <li><a href="#home">HOME</a><br></br></li>
        </ul>
      </nav>
      <center><h1>WELCOME TO OUR ADVENTURES WORLD</h1></center>
      <div1>
        <i><p>Restaurant management involves overseeing the daily operations of a restaurant, 
          ensuring that everything runs smoothly, from the kitchen to the dining area. 
          This role requires a combination of leadership, organization, and customer service skills. 
          Managers are responsible for hiring and training staff, creating work schedules, and ensuring that 
          food safety and cleanliness standards are met. They also handle the financial aspects of the restaurant, 
          such as budgeting, inventory management, and cost control</p></i>
          <h2>So Visit Our Website For More Informations</h2>
          <center>
          <h1>WE HAVE THE FACILITIES LIKE</h1> </center>
          <h3>FOOD FACILITIES</h3>
          <h3>BEVERAGES SERVICES</h3>
          <h3>Food Arrangement</h3>
          <h3>PRIVATE DINING BOOKING</h3>
          <b>
          <a href="https://www.agoda.com/en-in/pages/agoda/default/DestinationSearchResult.aspx?city=4923&site_id=1914936&tag=e081a7bf-69b1-402b-8772-24818941939a&msclkid=33da7d4f71961c9685501bf3f3a18ea9&ds=Z4CvIMe7pwDvlEPL">CLICK HERE TO BOOK YOU DATE</a>
          </b>
          
      </div1>
    </div>
  ); 


}

export default App;




































